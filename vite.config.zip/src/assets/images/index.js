import model from "./model.png";
import dove from "./dove.png";
import nivea from "./nivea.png";
import cetaphil from "./cetaphil.png";
import modelnew from "./modelnew.png";
import bg from "./bg.png";
import coffee from "./coffee.png";
import mocha from "./mocha.png";
import herbs from "./herbs.png";
import bg2 from "./bg2.jpg";
import bg3 from "./bg3.jpg";
import bg4 from "./bg4.png";
export {
  model,
  dove,
  nivea,
  cetaphil,
  modelnew,
  bg,
  coffee,
  mocha,
  herbs,
  bg2,
  bg3,
  bg4,
};
